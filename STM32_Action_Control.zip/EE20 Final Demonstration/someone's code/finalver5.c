/* USER CODE BEGIN Header */
	/**
	  ****
	  * @file           : main.c
	  * @brief          : Main program body
	  * @Author         :
	  * @Email          :
	  ****
	  * @attention
	  *
	  * Copyright (c) 2023 STMicroelectronics.
	  * All rights reserved.
	  *
	  * This software is licensed under terms that can be found in the LICENSE file
	  * in the root directory of this software component.
	  * If no LICENSE file comes with this software, it is provided AS-IS.
	  *
	  ****
	  */
	/* USER CODE END Header */
	/* Includes ------------------------------------------------------------------*/
	#include "main.h"
	#define FALSE 0
	#define TRUE 1
	/* Private includes ----------------------------------------------------------*/
	/* USER CODE BEGIN Includes */
	#include "stm32f1xx_hal.h"
	#include "stm32f1xx_hal_uart.h"
	#include <stdio.h>
	#include <string.h>
	#include <stdlib.h>
	#include <stdbool.h>
	#include <math.h>
	/* USER CODE END Includes */

	/* Private typedef -----------------------------------------------------------*/
	/* USER CODE BEGIN PTD */

	/* USER CODE END PTD */

	/* Private define ------------------------------------------------------------*/
	/* USER CODE BEGIN PD */
	/* USER CODE END PD */

	/* Private macro -------------------------------------------------------------*/
	/* USER CODE BEGIN PM */

	/* USER CODE END PM */

	/* Private variables ---------------------------------------------------------*/
	UART_HandleTypeDef huart1;
	UART_HandleTypeDef huart2;
	UART_HandleTypeDef huart3;

	/* USER CODE BEGIN PV */
	/*

	*/
	/* USER CODE END PV */

	/* Private function prototypes -----------------------------------------------*/
	void SystemClock_Config(void);
	static void MX_GPIO_Init(void);
	static void MX_USART2_UART_Init(void);
	static void MX_USART1_UART_Init(void);
	static void MX_USART3_UART_Init(void);
	/* USER CODE BEGIN PFP */

	// Litekit
	void moves(uint8_t* move);

	//void turn45(uint8_t* move);
	int movel(uint8_t* move, int duration);

	//printing
	void myprint(char* str);
	void intprint(uint16_t val);

	// Pixy Camera function declarations
	int8_t getVersion();
	int8_t getResolution();
	int8_t setCameraBrightness(uint8_t brightness);
	int8_t getBlocks(uint8_t sigmap, uint8_t maxBlocks);
	//checksum
	int8_t checksumcal(uint8_t* array);
	void rspeed(uint8_t* move);
	void bspeed(uint8_t* move);
	void lspeed(uint8_t* move);
	void fspeed(uint8_t* move);
	void trspeed(void);
	void tlspeed(void);
	void brspeed(void);
	void blspeed(void);

	// loop calculation
	uint16_t calc_loop(uint16_t diff);


	// Pixy Camera  declarations
	#define PIXY_DEFAULT_ARGVAL                  0x80000000
	#define PIXY_BUFFERSIZE                      0x104
	#define PIXY_CHECKSUM_SYNC                   0xc1af
	#define PIXY_NO_CHECKSUM_SYNC                0xc1ae
	#define PIXY_SEND_HEADER_SIZE                4
	#define PIXY_MAX_PROGNAME                    33
	#define PIXY_VERSION_BUFFERSIZE              22
	#define PIXY_RESOLUTION_BUFFERSIZE           10

	#define PIXY_TYPE_REQUEST_CHANGE_PROG        0x02
	#define PIXY_TYPE_REQUEST_RESOLUTION         0x0c
	#define PIXY_TYPE_RESPONSE_RESOLUTION        0x0d
	#define PIXY_TYPE_REQUEST_VERSION            0x0e
	#define PIXY_TYPE_RESPONSE_VERSION           0x0f
	#define PIXY_TYPE_RESPONSE_RESULT            0x01
	#define PIXY_TYPE_RESPONSE_ERROR             0x03
	#define PIXY_TYPE_REQUEST_BRIGHTNESS         0x10
	#define PIXY_TYPE_REQUEST_GETBLOCKS			 0x20
	#define PIXY_TYPE_REQUEST_SERVO              0x12
	#define PIXY_TYPE_REQUEST_LED                0x14
	#define PIXY_TYPE_REQUEST_LAMP               0x16
	#define PIXY_TYPE_REQUEST_FPS                0x18

	#define PIXY_RESULT_OK                       0
	#define PIXY_RESULT_ERROR                    -1
	#define PIXY_RESULT_BUSY                     -2
	#define PIXY_RESULT_CHECKSUM_ERROR           -3
	#define PIXY_RESULT_TIMEOUT                  -4
	#define PIXY_RESULT_BUTTON_OVERRIDE          -5
	#define PIXY_RESULT_PROG_CHANGING            -6

	// Pixy Camera getVersion declarations
	//uint8_t RequestPacket[4] = {0xc1, 0xae, 0x0e, 0x00};
	uint8_t reqV[] = {PIXY_NO_CHECKSUM_SYNC&0xff, PIXY_NO_CHECKSUM_SYNC>>8, PIXY_TYPE_REQUEST_VERSION, 0x00};
	uint8_t recV[PIXY_VERSION_BUFFERSIZE];
	int8_t checksumstateV = 0;
	int8_t checksumstateR = 0;
	int8_t checksumstateB = 0;
	int8_t checksumstateG = 0;
	// Pixy Camera getResolution declarations
	uint16_t getWidth = 0, getHeight = 0;
	//uint16_t 16BitChksum = 0;
	// Order: 1st byte of no_checksum_sync, 2nd byte of no_checksum_sync, 3rd byte-version request type, 4th byte-data length 1, 5th byte unused
	uint8_t reqR[] = {PIXY_NO_CHECKSUM_SYNC&0xff, PIXY_NO_CHECKSUM_SYNC>>8, PIXY_TYPE_REQUEST_RESOLUTION, 0x01, 0xFF};
	uint8_t VerR[] = {0xAE, 0xc1, 0x0d, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
	uint8_t recR[10];

	// Pixy Camera setCameraBrightness declarations
	//uint8_t setbright = 0;	// value of brightness to be 0 to 255 //add static if required
	// Order: Sync byte, sync byte, type of packet, length of payload, brightness
	uint8_t reqB[] = {PIXY_NO_CHECKSUM_SYNC&0xff, PIXY_NO_CHECKSUM_SYNC>>8, PIXY_TYPE_REQUEST_BRIGHTNESS, 0x01, 0xFF};
	uint8_t recB[10];

	// Pixy Camera getBlocks declarations
	uint8_t reqG[] = {PIXY_NO_CHECKSUM_SYNC&0xff, PIXY_NO_CHECKSUM_SYNC>>8, PIXY_TYPE_REQUEST_GETBLOCKS, 0x02, 0x01, 0x01};
	uint8_t recG[20];
	uint16_t X_BlkPix;  // 16-bit X (center) of block in pixels
	uint16_t Y_BlkPix;  // 16-bit Y (center) of block in pixels
	uint16_t WidthPix;  // 16-bit Width of block in pixels
	uint16_t HeightPix; // 16-bit Height of block in pixels
	uint16_t area;
	uint16_t zval; //initial value
	uint16_t xval; //initial value
	int8_t xstate;// -1(left), 0(neutral) , 1 (right)
	int8_t zstate;// -1(going further), 0(neutral) , 1 (going nearer)
	//checksum
	uint16_t checksum = 0;
	uint16_t cal_checksum = 0;
	//motor
	   const uint8_t dur = 0x64; //duration value
	  //3byes for data for all movements: direction, duration, speed, checksum
	  uint8_t fwd[] = {0x14, 0x01, 0x1E, 0x01}; //forward
	  uint8_t bck[] = {0x14, 0x02, 0x1E, 0x01};//backward
	  uint8_t left[] = {0x14, 0x03, 0x1E, 0x01};//turn left commented for now since not used
	  uint8_t right[] = {0x14, 0x04, 0x1E, 0x01};//turn right
	  uint8_t sleft[] = {0x14, 0x05, 0x1E, 0x01};//side left
	  uint8_t sright[] = {0x14, 0x06,0x1E, 0x01};//side right
	  uint8_t tleft[] = {0x14, 0x07, 0x1E, 0x01};//top left
	  uint8_t tright[] = {0x14, 0x08, 0x1E, 0x01};// top right
	  uint8_t bleft[] = {0x14, 0x09, 0x1E, 0x01};//bottom left
	  uint8_t bright[] = {0x14, 0x0A, 0x1E, 0x01};//bottom right
	  uint8_t stop[] = {0x14, 0x0B, 0x1E, 0x01};//stop
	  uint8_t speed = 0; //will further be initalized in speed function
	  uint8_t tmp = 0;
	  uint8_t review = 0;

	/* USER CODE END PFP */

	/* Private user code ---------------------------------------------------------*/
	/* USER CODE BEGIN 0 */

	/* USER CODE END 0 */

	/**
	  * @brief  The application entry point.
	  * @retval int
	  */
	int main(void)
	{
	  /* USER CODE BEGIN 1 */


	  /* USER CODE END 1 */

	  /* MCU Configuration--------------------------------------------------------*/

	  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	  HAL_Init();

	  /* USER CODE BEGIN Init */

	  /* USER CODE END Init */

	  /* Configure the system clock */
	  SystemClock_Config();

	  /* USER CODE BEGIN SysInit */

	  /* USER CODE END SysInit */

	  /* Initialize all configured peripherals */
	  MX_GPIO_Init();
	  MX_USART2_UART_Init();
	  MX_USART1_UART_Init();
	  MX_USART3_UART_Init();
	  /* USER CODE BEGIN 2 */

	  /* USER CODE END 2 */

	  /* Infinite loop */
	  /* USER CODE BEGIN WHILE */

	  while(1)//check for valid checksum
	  {
		checksumstateV = getVersion();
		HAL_Delay(1);
		checksumstateR = getResolution();
		HAL_Delay(1);
		checksumstateB = setCameraBrightness(100);
		HAL_Delay(1);
		HAL_Delay(100);
		while(!area)
		{
		checksumstateG = getBlocks(1,1);
		}
		HAL_Delay(1);
		xval = X_BlkPix;//store initial state of x axis
		zval = area;//store initial state of z axis
		//x axis in left and right, Z axis is away and near, with reference to Pixy Cam
		if(checksumstateV == 0 && checksumstateR == 0 && checksumstateB == 0 && checksumstateG == 0)//only if all is valid
		{
			break;
		}
	  }

	// buffer for x and y coordinates in pixels
	#define x_buffer 10
	// buffer for area in percentage
	#define area_buffer 60
	  while(1)//infinite main loop
	  {

		getBlocks(1,1);
		if(!area) //till area value is valid
		{
			movel(stop, 10);//send direction and for 10 times
			getBlocks(1,1);// current value of positon

		}else{
		uint16_t diff = ((zval/100)*area_buffer);
		uint16_t backdiff = ((zval/100)*5);
		xstate = X_BlkPix>(xval+x_buffer)?1:X_BlkPix<(xval-x_buffer)?-1:0;//store xval state, buffer of 5 units
		zstate = area>(zval+backdiff)?1:(area<(zval-backdiff)?-1:0);//store zval state


		if(zstate == -1 && xstate == 0) //x going left and z in bigger
		{
			review = 1;
			if(review!=tmp)
			{
				speed = 0;
			}
			tmp = review;
			myprint("forward\n");
			fspeed(fwd); // set speed
//			movel(fwd, 10);//send direction and for 10 times
		}
		else if(zstate == -1 && xstate == 1)
		{
			review = 2;
			if(review!=tmp)
			{
				speed = 0;
			}
			tmp = review;
			myprint("top right\n");
			rspeed(tright);// set speed
//			trspeed();
//			movel(tright, 10);//send direction and for 10 times
		}
		else if(zstate == 1 && xstate == 0)
		{
			review = 3;
			if(review!=tmp)
			{
				speed = 0;
			}
			tmp = review;
			myprint("backwards\n");
			bspeed(bck);// set speed
//			movel(bck, 10);//send direction and for 10 times
		}
		else if(zstate == -1 && xstate ==-1)
		{
			review = 4;
			if(review!=tmp)
			{
				speed = 0;
			}
			tmp = review;
			myprint("top left\n");
			lspeed(sleft);// set speed
//			tlspeed();
//			movel(tleft, 10);//send direction and for 10 times
		}
		else if(zstate == 1 && xstate ==-1)
		{
			review = 5;
			if(review!=tmp)
			{
				speed = 0;
			}
			tmp = review;
			myprint("bottom left\n");
			lspeed(sleft);// set speed
//			blspeed();
//			movel(bleft, 10);//send direction and for 10 times
		}
		else if(zstate == 1 && xstate == 1)
		{
			review = 6;
			if(review!=tmp)
			{
				speed = 0;
			}
			tmp = review;
			myprint("bottom right\n");
			rspeed(bright);// set speed
//			brspeed();
//			movel(bright, 10);//send direction and for 10 times
		}
		else if(zstate == 0 && xstate == 1)
		{
			review = 7;
			if(review!=tmp)
			{
				speed = 0;
			}
			tmp = review;
			myprint("side right\n");
			rspeed(sright);// set speed
//			movel(sright, 10);//send direction and for 10 times
		}
		else if(zstate == 0 && xstate == -1)
		{
			review = 8;
			if(review!=tmp)
			{
				speed = 0;
			}
			tmp = review;
			myprint("side left\n");
			lspeed(sleft);// set speed
//			movel(sleft, 10);//send direction and for 10 times
		}
		else if(zstate == 0 && xstate == 0)
		{
			review = 9;
			if(review!=tmp)
			{
				speed = 0;
			}
			tmp = review;
			myprint("stop\n");
			movel(stop, 10);//send direction and for 10 times
			// no speed required
		}
//		HAL_Delay(1);
		}// end area else
	  }

	}
	/* USER CODE END WHILE */

			/* USER CODE BEGIN 3 */

	unsigned int testmove(uint8_t*move, unsigned int test) //test movement that can be used if needed
	{
		for(;test!=0; test--)
		{
			HAL_Delay(20);
			uint8_t state = 0x0E; //initial state is notok aka ntok
			HAL_UART_Receive(&huart1, &state, sizeof(state), 100);
			if(state == 0x0E)
			{
				break;
			}
			HAL_UART_Transmit(&huart1, move, sizeof(move), 100);

		}
		return test;
	}

	void moves(uint8_t* move)//moves is move stop, used for stop
	{
		for(int i = 0; i<50; i++)
		{
			HAL_Delay(20);
			HAL_UART_Transmit(&huart1, move, sizeof(move), 100);
		}
	}
	#define delay_move 1
	int movel(uint8_t* move, int duration)//movel is move long, used for all other movements
	{
		move[2] = speed; //store speed
		move[3] = move[0] + move[1] + move[2];//store check sum by addition as total val is below 255
		for(int i = 0; i<duration;)//loop for
		{
			//HAL_Delay(delay_move);
			uint8_t state = 0x0E; //initial state is notok aka ntok
			HAL_UART_Receive(&huart1, &state, sizeof(state), 10); //receive and store
			HAL_UART_Transmit(&huart1, move, sizeof(move), 10);//transmit movement to comm2control
			if(state == 0x0F)//check state so that transmission only occurs when no obstacle
			{
				i++; //increment only if transmitted
			}
		}
		return 1;
	}
//	void turn45(uint8_t* move)//for 45 degree movement if required
//	{
//		for(int i = 0; i<1800; i++)
//		{
//				HAL_UART_Transmit(&huart1, move, sizeof(move), 200);
//		}
//
//	}

	// value for speed increments and decrements
	#define base_spd 1

	// side_offset is the difference between the x coordinate reading from getBlocks() and initialised x coordinate
	uint16_t side_offset;

	// area_offset is the difference between the area reading and the initialised area
	uint16_t area_offset;

	// offset buffer if needed
	//#define offset_buffer 0
	uint16_t offset_buffer = 0;

	// area percentage
	#define area_divider 20

	// area buffer
	uint16_t area_buff = 60;

	// max speed
	#define spd_cap 50

	// max speed for fwd and bck
	#define line_cap 50

	// for loop increments
	uint16_t scoop;

	// refer to x_buffer for buffer for x coordinates

	void rspeed(uint8_t* move)//right speed calculation
	{
		//can be multipled with other values to get different value for testing
		//speed = ((X_BlkPix - xval)/10)*10;//calculate change for acceleration
		side_offset = X_BlkPix - xval + offset_buffer;
//		if(side_offset){
//			scoop = 4;
//		}else if(side_offset > 10){
//			scoop = 8;
//		}else if(side_offset > 20){
//			scoop = 12;
//		}else if(side_offset > 30){
//			scoop = 16;
//		}else if(side_offset > 40){
//			scoop = 20;
//		}else if(side_offset > 50){
//			scoop = 24;
//		}else if(side_offset > 60){
//			scoop = 28;
//		}else if(side_offset > 70){
//			scoop = 32;
//		}else if(side_offset > 80){
//			scoop = 35;
//		}else if(side_offset > 90){
//			scoop = 38;
//		}else if(side_offset > 100){
//			scoop = 40;
//		}
//		scoop = side_offset ? 8 :
//		        side_offset > 15 ? 8 :
//		        side_offset > 20 ? 12 :
//		        side_offset > 30 ? 16 :
//		        side_offset > 40 ? 20 :
//		        side_offset > 50 ? 24 :
//		        side_offset > 60 ? 28 :
//		        side_offset > 70 ? 32 :
//		        side_offset > 80 ? 35 :
//		        side_offset > 90 ? 38 :
//		        side_offset > 100 ? 40 : side_offset;

		scoop = side_offset ? 5 :
		        side_offset > 10 ? 8 :
		        side_offset > 20 ? 12 :
		        side_offset > 30 ? 16 :
		        side_offset > 40 ? 20 :
		        side_offset > 50 ? 24 :
		        side_offset > 60 ? 28 :
		        side_offset > 70 ? 32 :
		        side_offset > 80 ? 35 :
		        side_offset > 90 ? 38 :
		        side_offset > 100 ? 40 :
				side_offset > 110 ? 45 :
				side_offset > 120 ? 50 : side_offset;

		for(uint16_t i = 0; i < scoop; i++){
			//speed += base_spd;
			if(X_BlkPix > (xval+x_buffer)){
				speed += base_spd;
			}else if(X_BlkPix < (xval+x_buffer)){
				speed -= base_spd;
			}
//			else if(X_BlkPix == (xval+x_buffer)){
//				speed = 0;
//			}
			move[2] = speed; //store speed
			move[3] = move[0] + move[1] + move[2];//store check sum by addition as total val is below 255
			uint8_t state = 0x0E; //initial state is notok aka ntok
			HAL_UART_Receive(&huart1, &state, sizeof(state), 10); //receive and store
			HAL_UART_Transmit(&huart1, move, sizeof(move), 10);//transmit movement to comm2control
			HAL_Delay(10);
		}
		speed = speed>spd_cap?spd_cap:speed;//cap speed at 30
	}
	void lspeed(uint8_t* move)//left speed calculation
	{
//		speed = ((xval - X_BlkPix)/10)*10;//calculate change for acceleration
//		side_offset = xval - X_BlkPix + offset_buffer;
//		for(uint16_t i = 0; i < side_offset; i++){
//			//speed += base_spd;
//			if(X_BlkPix < (xval+x_buffer)){
//				speed += base_spd;
//			}else if(X_BlkPix > (xval+x_buffer)){
//				speed -= base_spd;
//			}
//			else if(X_BlkPix == (xval+x_buffer)){
//				speed = 0;
//			}
//		}
//		speed = speed>spd_cap?spd_cap:speed;//cap speed at 30

		side_offset = xval - X_BlkPix + offset_buffer;
//		scoop = side_offset ? 8 :
//		        side_offset > 15 ? 8 :
//		        side_offset > 20 ? 12 :
//		        side_offset > 30 ? 16 :
//		        side_offset > 40 ? 20 :
//		        side_offset > 50 ? 24 :
//		        side_offset > 60 ? 28 :
//		        side_offset > 70 ? 32 :
//		        side_offset > 80 ? 35 :
//		        side_offset > 90 ? 38 :
//		        side_offset > 100 ? 40 : side_offset;

		scoop = side_offset ? 5 :
		        side_offset > 10 ? 8 :
		        side_offset > 20 ? 12 :
		        side_offset > 30 ? 16 :
		        side_offset > 40 ? 20 :
		        side_offset > 50 ? 24 :
		        side_offset > 60 ? 28 :
		        side_offset > 70 ? 32 :
		        side_offset > 80 ? 35 :
		        side_offset > 90 ? 38 :
		        side_offset > 100 ? 40 :
				side_offset > 110 ? 45 :
				side_offset > 120 ? 50 : side_offset;

		for(uint16_t i = 0; i < scoop; i++){
			//speed += base_spd;
			if(X_BlkPix < (xval+x_buffer)){
				speed += base_spd;
			}else if(X_BlkPix > (xval+x_buffer)){
				speed -= base_spd;
			}
//			else if(X_BlkPix == (xval+x_buffer)){
//				speed = 0;
//			}
			move[2] = speed; //store speed
			move[3] = move[0] + move[1] + move[2];//store check sum by addition as total val is below 255
			uint8_t state = 0x0E; //initial state is notok aka ntok
			HAL_UART_Receive(&huart1, &state, sizeof(state), 10); //receive and store
			HAL_UART_Transmit(&huart1, move, sizeof(move), 10);//transmit movement to comm2control
			HAL_Delay(10);
		}
		speed = speed>spd_cap?spd_cap:speed;//cap speed at 30
	}
	void fspeed(uint8_t* move)//front speed calculation
	{
//		// offset difference in area
////		speed = ((zval - area)/area) * area_divider;//calculate change for acceleration
//		area_offset = ((zval - area)/area) * area_divider;
//		scoop = (area<zval+20) ? 10 :
//				(area<zval+40) ? 15 :
//				(area<zval+60) ? 20 :
//				(area<zval+80) ? 25 :
//				(area<zval+100)? 30 :
//				(area<zval+120)? 35 :
//				(area<zval+140)? 40 :
//				(area<zval+160)? 45 :
//				(area<zval+180)? 50 : scoop;

//		scoop = (area>zval+15) ? 10 :
//				(area>zval+30) ? 15 :
//				(area>zval+45) ? 20 :
//				(area>zval+60) ? 25 :
//				(area>zval+75)?  30 :
//				(area>zval+90)?  35 :
//				(area>zval+105)? 40 :
//				(area>zval+120)? 45 :
//				(area>zval+135)? 50 : scoop;

//		scoop = (area>zval+5) ? 10 :
//				(area>zval+10) ? 15 :
//				(area>zval+15) ? 20 :
//				(area>zval+20) ? 25 :
//				(area>zval+25)?  30 :
//				(area>zval+30)?  35 :
//				(area>zval+35)? 40 :
//				(area>zval+40)? 45 :
//				(area>zval+45)? 50 : scoop;

//		for(uint16_t i = 0; i < scoop; i++){
//			//speed += base_spd;
//			if(area < (zval+area_buff)){
//				speed += base_spd;
//			}else if(area > (zval+area_buff)){
//				speed -= base_spd;
//			}
//			else if(X_BlkPix == (xval+x_buffer)){
//				speed = 0;
//			}
//			speed = 30;
//			move[2] = speed; //store speed
//			move[3] = move[0] + move[1] + move[2];//store check sum by addition as total val is below 255
//			uint8_t state = 0x0E; //initial state is notok aka ntok
//			HAL_UART_Receive(&huart1, &state, sizeof(state), 10); //receive and store
//			HAL_UART_Transmit(&huart1, move, sizeof(move), 10);//transmit movement to comm2control
//			HAL_Delay(1);

			speed = 45;
			move[2] = speed; //store speed
			move[3] = move[0] + move[1] + move[2];//store check sum by addition as total val is below 255
			for(int i = 0; i<10;)//loop for
			{
				//HAL_Delay(delay_move);
				uint8_t state = 0x0E; //initial state is notok aka ntok
				HAL_UART_Receive(&huart1, &state, sizeof(state), 10); //receive and store
				HAL_UART_Transmit(&huart1, move, sizeof(move), 10);//transmit movement to comm2control
				if(state == 0x0F)//check state so that transmission only occurs when no obstacle
				{
					i++; //increment only if transmitted
				}
			}
//		}

		speed = speed>line_cap?line_cap:speed;//cap speed at 30
	}
	void bspeed(uint8_t* move)//Back speed calculation
	{
		// calculate offset difference in area
//		speed = ((area - zval)/zval) * area_divider;//calculate change for acceleration
//		scoop = (area>zval+20)?10:(area>zval+40)?15:(area>zval+60)?20:(area>zval+80)?25:(area>zval+80)?30:scoop;

//		scoop = (area>zval+20) ? 10 :
//				(area>zval+40) ? 15 :
//				(area>zval+60) ? 20 :
//				(area>zval+80) ? 25 :
//				(area>zval+100)? 30 :
//				(area>zval+120)? 35 :
//				(area>zval+140)? 40 :
//				(area>zval+160)? 45 :
//				(area>zval+180)? 50 : scoop;

//		scoop = (area>zval+15) ? 10 :
//				(area>zval+30) ? 15 :
//				(area>zval+45) ? 20 :
//				(area>zval+60) ? 25 :
//				(area>zval+75)?  30 :
//				(area>zval+90)?  35 :
//				(area>zval+105)? 40 :
//				(area>zval+120)? 45 :
//				(area>zval+135)? 50 : scoop;

//		scoop = (area>zval+5)  ? 10 :
//				(area>zval+10) ? 15 :
//				(area>zval+15) ? 20 :
//				(area>zval+20) ? 25 :
//				(area>zval+25) ?  30 :
//				(area>zval+30) ?  35 :
//				(area>zval+35) ? 40 :
//				(area>zval+40) ? 45 :
//				(area>zval+45) ? 50 : scoop;

//		for(uint16_t i = 0; i < scoop; i++){
//			//speed += base_spd;
//			if(area > (zval+area_buff)){
//				speed += base_spd;
//			}else if(area < (zval+area_buff)){
//				speed -= base_spd;
//			}
//			else if(X_BlkPix == (xval+x_buffer)){
//				speed = 0;
//			}
//			speed = 30;
//			move[2] = speed; //store speed
//			move[3] = move[0] + move[1] + move[2];//store check sum by addition as total val is below 255
//			uint8_t state = 0x0E; //initial state is notok aka ntok
//			HAL_UART_Receive(&huart1, &state, sizeof(state), 10); //receive and store
//			HAL_UART_Transmit(&huart1, move, sizeof(move), 10);//transmit movement to comm2control
//			HAL_Delay(1);
//		}

		speed = 45;
		move[2] = speed; //store speed
		move[3] = move[0] + move[1] + move[2];//store check sum by addition as total val is below 255
		for(int i = 0; i<10;)//loop for
		{
			//HAL_Delay(delay_move);
			uint8_t state = 0x0E; //initial state is notok aka ntok
			HAL_UART_Receive(&huart1, &state, sizeof(state), 10); //receive and store
			HAL_UART_Transmit(&huart1, move, sizeof(move), 10);//transmit movement to comm2control
			if(state == 0x0F)//check state so that transmission only occurs when no obstacle
			{
				i++; //increment only if transmitted
			}
		}
		speed = speed>line_cap?line_cap:speed;//cap speed at 30
	}

	// diagonal movement speed calculation
	void trspeed(void){// diagonal right forward
		//speed = ((zval - area)/area) * area_divider;//calculate change for acceleration

		// calculate offset difference in area
		area_offset = ((zval - area)/area) * area_divider;

		// offset difference on x-axis
		side_offset = X_BlkPix - xval + offset_buffer;

		// final offset
//		uint16_t final_offset = sqrt((area_offset^2) + (side_offset^2));

		// Desired values: X_BlkPix = xval, area = zval, these values are the set point
		// the calculations is the compen
		for(uint16_t j = 0; j < side_offset; j++){
//			while((X_BlkPix != xval+x_buffer) && (zval != area)){
				if((X_BlkPix > xval+x_buffer) || (area > zval)){
					speed += base_spd;
				}else if((X_BlkPix < xval +x_buffer) || (area < zval)){
					speed -= base_spd;
				}
//			}
		}
		speed = speed>spd_cap?spd_cap:speed;//cap speed at 30
	}
	void tlspeed(void){// diagonal left forward
		//speed = ((zval - area)/area) * area_divider;//calculate c hange for acceleration

		// calculate offset difference in area
		area_offset = ((zval - area)/area) * area_divider;

		// offset difference on x-axis
		side_offset = xval - X_BlkPix + offset_buffer;

		// final offset
//		uint16_t final_offset = sqrt((area_offset^2) + (side_offset^2));

		for(uint16_t j = 0; j < side_offset; j++){
//			while((X_BlkPix != xval+x_buffer) && (zval != area)){
				if((X_BlkPix < xval+x_buffer) || (area > zval)){
					speed += base_spd;
				}else if((X_BlkPix > xval+x_buffer) || (area < zval)){
					speed -= base_spd;
				}else if((X_BlkPix == xval+x_buffer) || (area == zval)){
					speed = 0;
				}
//			}
		}
		speed = speed>spd_cap?spd_cap:speed;//cap speed at 30
	}
	void brspeed(void){// diagonal right reverse
		//speed = ((zval - area)/area) * area_divider;//calculate change for acceleration

		// calculate offset difference in area
		area_offset = ((area - zval)/zval) * area_divider;

		// offset difference on x-axis
		side_offset = X_BlkPix - xval + offset_buffer;

		// final offset
//		uint16_t final_offset = sqrt((area_offset^2) + (side_offset^2));

		for(uint16_t j = 0; j < side_offset; j++){
//			while((X_BlkPix != xval+x_buffer) && (zval != area)){
				if((X_BlkPix > xval+x_buffer) || (area > zval)){
					speed += base_spd;
				}else if((X_BlkPix < xval+x_buffer) || (area < zval)){
					speed -= base_spd;
				}
//           			}
		}
		speed = speed>spd_cap?spd_cap:speed;//cap speed at 30
	}
	void blspeed(void){// diagonal left reverse
		//speed = ((zval - area)/area) * area_divider;//calculate change for acceleration

		// calculate offset difference in area
		area_offset = ((area - zval)/zval) * area_divider;

		// offset difference on x-axis
		side_offset = xval - X_BlkPix + offset_buffer;

		// final offset
		//uint16_t final_offset = sqrt((area_offset^2) + (side_offset^2));

		for(uint16_t j = 0; j < side_offset; j++){
//			while((X_BlkPix != xval+x_buffer) && (zval != area)){
				if((X_BlkPix < xval+x_buffer) || (area > zval)){
					speed += base_spd;
				}else if((X_BlkPix > xval+x_buffer) || (area < zval)){
					speed -= base_spd;
				}
//			}
		}
		speed = speed>spd_cap?spd_cap:speed;//cap speed at 30
	}
	//print a string of max 50 letters
	void myprint(char *str)//print a sting of max 50 char
	{
		char print[50] = {'\0'}; // buffer
		sprintf(print, "%s", str);
		HAL_UART_Transmit(&huart2, (uint8_t *)print, strlen(print), 100);

	}
	//print a 2byte int
	void intprint(uint16_t val)//print an unsigned int
	{
		char print[50] = {'\0'}; // buffer
		sprintf(print, "%u", val);
		HAL_UART_Transmit(&huart2, (uint8_t *)print, strlen(print), 100);
	}
	// PIXY CAMERA


	// Order: 1st byte of no_checksum_sync, 2nd byte of no_checksum_sync, 3rd byte-version request type, 4th byte-data length 0
	// To request hardware and firmware version data

	int8_t checksumcal(uint8_t* array)//calculate checksum of pixycam
	{
		checksum = array[5] << 8 | array[4];
		cal_checksum = 0;
		for(int i = 6; i<22;i++)
		{
			cal_checksum+=array[i];
		}
		return checksum==cal_checksum?PIXY_RESULT_OK:PIXY_RESULT_ERROR;
	}
	int8_t getVersion()//get the current version of  Pixy cam
	{
		HAL_UART_Transmit(&huart3, reqV, 4, 100);
		HAL_UART_Receive(&huart3, recV, PIXY_VERSION_BUFFERSIZE, 100);
		HAL_Delay(1);
		return checksumcal(recV);
		//if loop to check error;
	}
	// getResolution gets the width and height of the frames used by the current program
	int8_t getResolution()//get the resolution of  Pixy cam
	{
		HAL_UART_Transmit(&huart3, reqR, 5, 100);
		HAL_UART_Receive(&huart3, recR, 10, 100);
		HAL_Delay(1);
		return checksumcal(recR);
	}
	// setCameraBrightness
	// Taken from Pixy camera docu: sets the relative exposure level of Pixy2's image sensor. Higher values result in a brighter (more exposed) image.
	// Verify brightness response packet
	// Order: 8 bit sync byte, 8 bit sync byte, types of packet, length of payload, 4-5 16 bit checksum, 6-9 32 bit brightness
	uint8_t VerBright[] = {0xC1, 0xAF, 0x01, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
	int8_t setCameraBrightness(uint8_t setbright)//set the current brightness of  Pixy cam, set to 100 for testing
	{
		reqB[4] = setbright;//store brightness value
		HAL_UART_Transmit(&huart3, reqB, 5, 100);
		HAL_UART_Receive(&huart3, recB, 10, 100);
		HAL_Delay(1);
		checksum = recB[5] << 8 | recB[4];
		cal_checksum = 0;
		for(int i = 6; i<sizeof(recB);i++)
		{
			cal_checksum+=recB[i];
		}
		return checksum==cal_checksum?PIXY_RESULT_OK:PIXY_RESULT_ERROR;
	}
	// if receive center of object that litekit is tracking, how to use coordinates to classify movements slight left?
	// diagonally left? coordinates and size must take this into account, use get blocks, set threshold when setting motion
	// based on height and width of object
	// if moves further away, center of object moves to the right andf getting smaller, motion cannot be just slightly right
	// must be diagonally right
	// devise this into flowchart

	// getBlocks, gets all the detected blocks in the most recent frame
	// Description taken from pixy cam documentation
	// the returned blocks are sorted by area, with the largest blocks appearing first in the blocks array.
	// returns an error value (<0) if it fails and the number of detected blocks (>=0) if it succeeds.
	// sigmap is a bitmap of all 7 signatures from which you wish to receive block data.
	// if you are only interested in block data from signature 1, you would pass in a value of 1.
	// If you are interested in block data from both signatures 1 and 2, you would pass in a value of 3.
	// If you are interested in block data from signatures 1, 2, and 3, you would pass a value of 7, and so on.
	// The most-significant-bit (128 or 0x80) is used for color-codes.
	// A value of 255 (default) indicates that you are interested in all block data.

	// maxblocks is the maximum number of blocks you want to receive.
	// passing 1 will receive one block, passing 255 will receive all blocks.

	//uint8_t sigmap = 0xFF;//for sigmap value for 1
	//uint8_t maxBlocks = 0x01;
	//uint8_t VerBlock[] = {0xC1, 0xAF, 0x21, 0x0E, 0x00, 0x00, // last two bytes are sum of payload bytes
	//					  0x00, 0x00, 0x00, 0x00, // 16-bit signature, 16-bit X (center) of block in pixels
	//					  0x00, 0x00, 0x00, 0x00, // 16-bit Y (center) of block in pixels, 16-bit Width of block in pixels
	//					  0x00, 0x00, 0x00, 0x00, // 16-bit Height of block in pixels, 16-bit Angle of color-code in degrees
	//					  0x00, 0x00			  // Tracking index of block (see API for more info), Age - number of frames this block has been tracked
	//					  };
	//

	//
	//uint16_t signature = 0; // colour code number
	//uint16_t X_BlkPix = 0;  // 16-bit X (center) of block in pixels
	//uint16_t Y_BlkPix = 0;  // 16-bit Y (center) of block in pixels
	//uint16_t WidthPix = 0;  // 16-bit Width of block in pixels
	//uint16_t HeightPix = 0; // 16-bit Height of block in pixels
	//int16_t AngleCode = 0; // 16-bit Angle of color-code in degrees -180 - 180 (0 if not a color code)
	//uint8_t TrackIdx = 0;   // Tracking index of block (see API for more info)
	//uint8_t Age = 0;	    // Age - number of frames this block has been tracked
	//int16_t getPayloadSum = 0;

	int8_t getBlocks(uint8_t sigmap, uint8_t maxBlocks)//getblocks function to get X,Y coordinates and Calculate Area
	{
		HAL_UART_Transmit(&huart3, reqG, 6, 100);
		HAL_UART_Receive(&huart3, recG, 20, 100);
		X_BlkPix = ((uint16_t)recG[9] << 8)| recG[8];//Bitshift to find x Val
		Y_BlkPix = ((uint16_t)recG[11] << 8)| recG[10];//Bitshift to find Y Val
		WidthPix = ((uint16_t)recG[13] << 8)| recG[12];//Bitshift to find Width
		HeightPix = ((uint16_t)recG[15] << 8)| recG[14];//Bitshift to find Height
		area = WidthPix*HeightPix;// Calculate and store area
		checksum = recG[5] << 8 | recG[4];
		cal_checksum = 0;
		for(int i = 6; i<sizeof(recG);i++)
		{
			cal_checksum+=recG[i];
		}
		return checksum==cal_checksum?PIXY_RESULT_OK:PIXY_RESULT_ERROR;

	}

	  /* USER CODE END 3 */


	/**
	  * @brief System Clock Configuration
	  * @retval None
	  */
	void SystemClock_Config(void)
	{
	  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
	  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

	  /** Initializes the RCC Oscillators according to the specified parameters
	  * in the RCC_OscInitTypeDef structure.
	  */
	  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
	  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
	  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
	  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
	  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI_DIV2;
	  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL16;
	  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
	  {
		Error_Handler();
	  }

	  /** Initializes the CPU, AHB and APB buses clocks
	  */
	  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
								  |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
	  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
	  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
	  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
	  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

	  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
	  {
		Error_Handler();
	  }
	}

	/**
	  * @brief USART1 Initialization Function
	  * @param None
	  * @retval None
	  */
	static void MX_USART1_UART_Init(void)
	{

	  /* USER CODE BEGIN USART1_Init 0 */

	  /* USER CODE END USART1_Init 0 */

	  /* USER CODE BEGIN USART1_Init 1 */

	  /* USER CODE END USART1_Init 1 */
	  huart1.Instance = USART1;
	  huart1.Init.BaudRate = 115200;
	  huart1.Init.WordLength = UART_WORDLENGTH_8B;
	  huart1.Init.StopBits = UART_STOPBITS_1;
	  huart1.Init.Parity = UART_PARITY_NONE;
	  huart1.Init.Mode = UART_MODE_TX_RX;
	  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
	  if (HAL_UART_Init(&huart1) != HAL_OK)
	  {
		Error_Handler();
	  }
	  /* USER CODE BEGIN USART1_Init 2 */

	  /* USER CODE END USART1_Init 2 */

	}

	/**
	  * @brief USART2 Initialization Function
	  * @param None
	  * @retval None
	  */
	static void MX_USART2_UART_Init(void)
	{

	  /* USER CODE BEGIN USART2_Init 0 */

	  /* USER CODE END USART2_Init 0 */

	  /* USER CODE BEGIN USART2_Init 1 */

	  /* USER CODE END USART2_Init 1 */
	  huart2.Instance = USART2;
	  huart2.Init.BaudRate = 115200;
	  huart2.Init.WordLength = UART_WORDLENGTH_8B;
	  huart2.Init.StopBits = UART_STOPBITS_1;
	  huart2.Init.Parity = UART_PARITY_NONE;
	  huart2.Init.Mode = UART_MODE_TX_RX;
	  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
	  if (HAL_UART_Init(&huart2) != HAL_OK)
	  {
		Error_Handler();
	  }
	  /* USER CODE BEGIN USART2_Init 2 */

	  /* USER CODE END USART2_Init 2 */

	}

	/**
	  * @brief USART3 Initialization Function
	  * @param None
	  * @retval None
	  */
	static void MX_USART3_UART_Init(void)
	{

	  /* USER CODE BEGIN USART3_Init 0 */

	  /* USER CODE END USART3_Init 0 */

	  /* USER CODE BEGIN USART3_Init 1 */

	  /* USER CODE END USART3_Init 1 */
	  huart3.Instance = USART3;
	  huart3.Init.BaudRate = 115200;
	  huart3.Init.WordLength = UART_WORDLENGTH_8B;
	  huart3.Init.StopBits = UART_STOPBITS_1;
	  huart3.Init.Parity = UART_PARITY_NONE;
	  huart3.Init.Mode = UART_MODE_TX_RX;
	  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
	  if (HAL_UART_Init(&huart3) != HAL_OK)
	  {
		Error_Handler();
	  }
	  /* USER CODE BEGIN USART3_Init 2 */

	  /* USER CODE END USART3_Init 2 */

	}

	/**
	  * @brief GPIO Initialization Function
	  * @param None
	  * @retval None
	  */
	static void MX_GPIO_Init(void)
	{
	  GPIO_InitTypeDef GPIO_InitStruct = {0};

	  /* GPIO Ports Clock Enable */
	  __HAL_RCC_GPIOC_CLK_ENABLE();
	  __HAL_RCC_GPIOD_CLK_ENABLE();
	  __HAL_RCC_GPIOA_CLK_ENABLE();
	  __HAL_RCC_GPIOB_CLK_ENABLE();

	  /*Configure GPIO pin Output Level */
	  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);

	  /*Configure GPIO pin : B1_Pin */
	  GPIO_InitStruct.Pin = B1_Pin;
	  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
	  GPIO_InitStruct.Pull = GPIO_NOPULL;
	  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

	  /*Configure GPIO pin : LD2_Pin */
	  GPIO_InitStruct.Pin = LD2_Pin;
	  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	  GPIO_InitStruct.Pull = GPIO_NOPULL;
	  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);

	  /* EXTI interrupt init*/
	  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
	  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

	}

	/* USER CODE BEGIN 4 */

	/* USER CODE END 4 */

	/**
	  * @brief  This function is executed in case of error occurrence.
	  * @retval None
	  */
	void Error_Handler(void)
	{
	  /* USER CODE BEGIN Error_Handler_Debug */
	  /* User can add his own implementation to report the HAL error return state */
	  __disable_irq();
	  while (1)
	  {
	  }
	  /* USER CODE END Error_Handler_Debug */
	}

	#ifdef  USE_FULL_ASSERT
	/**
	  * @brief  Reports the name of the source file and the source line number
	  *         where the assert_param error has occurred.
	  * @param  file: pointer to the source file name
	  * @param  line: assert_param error line source number
	  * @retval None
	  */
	void assert_failed(uint8_t *file, uint32_t line)
	{
	  /* USER CODE BEGIN 6 */
	  /* User can add his own implementation to report the file name and line number,
		 ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
	  /* USER CODE END 6 */
	}
	#endif /* USE_FULL_ASSERT */




///////////////////


///* USER CODE BEGIN Header */
///**
//  **************************
//  * @file           : main.c
//  * @brief          : Main program body
//  **************************
//  * @attention
//  *
//  * Copyright (c) 2023 STMicroelectronics.
//  * All rights reserved.
//  *
//  * This software is licensed under terms that can be found in the LICENSE file
//  * in the root directory of this software component.
//  * If no LICENSE file comes with this software, it is provided AS-IS.
//  *
//  **************************
//  */
///* USER CODE END Header */
///* Includes ------------------------------------------------------------------*/
//#include "main.h"
//#include "stm32f1xx_hal.h"
//#include "stm32f1xx_hal_uart.h"
//
//
///* Private variables ---------------------------------------------------------*/
//UART_HandleTypeDef huart1;
//UART_HandleTypeDef huart2;
//UART_HandleTypeDef huart3;
//
//
///* Private function prototypes -----------------------------------------------*/
//void SystemClock_Config(void);
//static void MX_GPIO_Init(void);
//static void MX_USART2_UART_Init(void);
//static void MX_USART1_UART_Init(void);
//static void MX_USART3_UART_Init(void);
//void moves(uint8_t* move);
////void turn45(uint8_t* move);
//void movel(uint8_t* move, int duration);
////unsigned int testmove(uint8_t*move, unsigned int test);
//
///**
//  * @brief  The application entry point.
//  * @retval int
//  */
//int main(void)
//{
//  HAL_Init();//INITIALIZE
//  SystemClock_Config();
//  MX_GPIO_Init();
//  MX_USART2_UART_Init();
//  MX_USART1_UART_Init();//INITIALIZE for use in comm2control
//  MX_USART3_UART_Init();
//  uint8_t dur = 0x64; //duration value
//  //3byes for data for all movements: direction, duration, checksum
//  uint8_t fwd[3] = {0x01, dur, 0x01+dur}; //forward
//  uint8_t bck[3] = {0x02, dur, 0x02+dur};//backward
//  //uint8_t left[3] = {0x03, dur, 0x03+dur};//turn left commented for now since not used
//  //uint8_t right[3] = {0x04, dur, 0x04+dur};//turn right
//  uint8_t sleft[3] = {0x05, dur, 0x05+dur};//side left
//  uint8_t sright[3] = {0x06, dur, 0x06+dur};//side right
//  uint8_t tleft[3] = {0x07, dur, 0x07+dur};//top left
//  uint8_t tright[3] = {0x08, dur, 0x08+dur};// top right
//  uint8_t bleft[3] = {0x09, dur, 0x09+dur};//bottom left
//  uint8_t bright[3] = {0x0A, dur, 0x0A+dur};//bottom right
//  uint8_t stop[3] = {0x0B, dur, 0x0B+dur};//stop
//  int d = 80;
//
// // getBlock(1,2, p1, p2);
//
////  	moves(stop);//need for wait for buffer
////  	moves(stop);//initial stop for safety in case of accidental turning on
//
//
////	movel(fwd, d); //movements as specified in assignment
////	moves(stop);
////	movel(tright, d);
////	moves(stop);
////	movel(sright, d);
////	moves(stop);
////	movel(bright, d);
////	moves(stop);
////	movel(bck, d);
////	moves(stop);
////	movel(bleft, d);
////	moves(stop);
////	movel(sleft, d);
////	moves(stop);
////	movel(tleft, d);
////	moves(stop);
//
////	movel(bck, d);
//	while(1)//loop forever
//	{
//		movel(fwd, d); //movements as specified in assignment
//		moves(stop);
//		movel(tright, d);
//		moves(stop);
//		movel(sright, d);
//		moves(stop);
//		movel(bright, d);
//		moves(stop);
//		movel(bck, d);
//		moves(stop);
//		movel(bleft, d);
//		moves(stop);
//		movel(sleft, d);
//		moves(stop);
//		movel(tleft, d);
//		moves(stop);
////		break;
//
////		movel(tleft, d);
////		movel(bright, d);
////		movel(tright, d);
////		movel(bleft, d);
//	}
//}
//
////unsigned int testmove(uint8_t*move, unsigned int test)
////{
////	for(;test!=0; test--)
////	{
////		HAL_Delay(20);
////		uint8_t state = 0x0E; //initial state is notok aka ntok
////		HAL_UART_Receive(&huart1, &state, sizeof(move), 10);
////		if(state == 0x0E)
////		{
////			break;
////		}
////		HAL_UART_Transmit(&huart1, move, sizeof(move), 10);
////
////	}
////	return test;
////}
//
//void moves(uint8_t* move)//moves is move stop, used for stop
//{
//	for(int i = 0; i<50; i++)
//	{
//		HAL_Delay(20);
//		HAL_UART_Transmit(&huart1, move, sizeof(move), 10);
//	}
//}
//void movel(uint8_t* move, int duration)//movel is move long, used for all other movements
//{
//
//	for(int i = 0; i<duration;)//loop for
//	{
//		HAL_Delay(20);
//		uint8_t state = 0x0E; //initial state is notok aka ntok
//
//		HAL_UART_Receive(&huart1, &state, sizeof(state), 10); //receive and store
//		HAL_UART_Transmit(&huart1, move, sizeof(move), 10);//transmit movement to comm2control
//		if(state == 0x0F)//check state so that transmission only occurs when no obstacle
//		{
//			 i++; //increment only if transmitted
//		}
//	}
//}
////void turn45(uint8_t* move)//for 45 degree movement if required
////{
////	for(int i = 0; i<1800; i++)
////	{
////			HAL_UART_Transmit(&huart1, move, sizeof(move), 200);
////	}
////
////}
//
//void SystemClock_Config(void)
//{
//  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
//  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
//
//  /** Initializes the RCC Oscillators according to the specified parameters
//  * in the RCC_OscInitTypeDef structure.
//  */
//  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
//  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
//  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
//  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
//  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI_DIV2;
//  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL16;
//  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
//  {
//    Error_Handler();
//  }
//
//  /** Initializes the CPU, AHB and APB buses clocks
//  */
//  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
//                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
//  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
//  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
//  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
//  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
//
//  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
//  {
//    Error_Handler();
//  }
//}
//
///**
//  * @brief USART1 Initialization Function
//  * @param None
//  * @retval None
//  */
//static void MX_USART1_UART_Init(void)
//{
//  huart1.Instance = USART1;
//  huart1.Init.BaudRate = 115200;
//  huart1.Init.WordLength = UART_WORDLENGTH_8B;
//  huart1.Init.StopBits = UART_STOPBITS_1;
//  huart1.Init.Parity = UART_PARITY_NONE;
//  huart1.Init.Mode = UART_MODE_TX_RX;
//  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
//  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
//  if (HAL_UART_Init(&huart1) != HAL_OK)
//  {
//    Error_Handler();
//  }
//}
//
//
//static void MX_USART2_UART_Init(void)
//{
//
//
//  huart2.Instance = USART2;
//  huart2.Init.BaudRate = 115200;
//  huart2.Init.WordLength = UART_WORDLENGTH_8B;
//  huart2.Init.StopBits = UART_STOPBITS_1;
//  huart2.Init.Parity = UART_PARITY_NONE;
//  huart2.Init.Mode = UART_MODE_TX_RX;
//  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
//  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
//  if (HAL_UART_Init(&huart2) != HAL_OK)
//  {
//    Error_Handler();
//  }
//
//}
//
///**
//  * @brief USART3 Initialization Function
//  * @param None
//  * @retval None
//  */
//static void MX_USART3_UART_Init(void)
//{
//
//
//  huart3.Instance = USART3;
//  huart3.Init.BaudRate = 115200;
//  huart3.Init.WordLength = UART_WORDLENGTH_8B;
//  huart3.Init.StopBits = UART_STOPBITS_1;
//  huart3.Init.Parity = UART_PARITY_NONE;
//  huart3.Init.Mode = UART_MODE_TX_RX;
//  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
//  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
//  if (HAL_UART_Init(&huart3) != HAL_OK)
//  {
//    Error_Handler();
//  }
//
//}
//
///**
//  * @brief GPIO Initialization Function
//  * @param None
//  * @retval None
//  */
//static void MX_GPIO_Init(void)
//{
//  GPIO_InitTypeDef GPIO_InitStruct = {0};
//
//  /* GPIO Ports Clock Enable */
//  __HAL_RCC_GPIOC_CLK_ENABLE();
//  __HAL_RCC_GPIOD_CLK_ENABLE();
//  __HAL_RCC_GPIOA_CLK_ENABLE();
//  __HAL_RCC_GPIOB_CLK_ENABLE();
//
//  /*Configure GPIO pin Output Level */
//  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);
//
//  /*Configure GPIO pin : B1_Pin */
//  GPIO_InitStruct.Pin = B1_Pin;
//  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
//  GPIO_InitStruct.Pull = GPIO_NOPULL;
//  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);
//
//  /*Configure GPIO pin : LD2_Pin */
//  GPIO_InitStruct.Pin = LD2_Pin;
//  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
//  GPIO_InitStruct.Pull = GPIO_NOPULL;
//  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
//  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);
//
//  /* EXTI interrupt init*/
//  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
//  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);
//
//}
//
///* USER CODE BEGIN 4 */
//
///* USER CODE END 4 */
//
///**
//  * @brief  This function is executed in case of error occurrence.
//  * @retval None
//  */
//void Error_Handler(void)
//{
//  /* USER CODE BEGIN Error_Handler_Debug */
//  /* User can add his own implementation to report the HAL error return state */
//  __disable_irq();
//  while (1)
//  {
//  }
//  /* USER CODE END Error_Handler_Debug */
//}
//
//#ifdef  USE_FULL_ASSERT
///**
//  * @brief  Reports the name of the source file and the source line number
//  *         where the assert_param error has occurred.
//  * @param  file: pointer to the source file name
//  * @param  line: assert_param error line source number
//  * @retval None
//  */
//void assert_failed(uint8_t *file, uint32_t line)
//{
//  /* USER CODE BEGIN 6 */
//  /* User can add his own implementation to report the file name and line number,
//     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
//  /* USER CODE END 6 */
//}
//#endif /* USE_FULL_ASSERT */



//////////////////////////////////////////////////////////////
//	/* Includes ------------------------------------------------------------------*/
//	#include "main.h"
//	#define FALSE 0
//	#define TRUE 1
//	/* Private includes ----------------------------------------------------------*/
//	/* USER CODE BEGIN Includes */
//	#include "stm32f1xx_hal.h"
//	#include "stm32f1xx_hal_uart.h"
//	#include <stdio.h>
//	#include <string.h>
//	#include <stdlib.h>
//	#include <stdbool.h>
//	/* USER CODE END Includes */
//
//	/* Private typedef -----------------------------------------------------------*/
//	/* USER CODE BEGIN PTD */
//
//	/* USER CODE END PTD */
//
//	/* Private define ------------------------------------------------------------*/
//	/* USER CODE BEGIN PD */
//	/* USER CODE END PD */
//
//	/* Private macro -------------------------------------------------------------*/
//	/* USER CODE BEGIN PM */
//
//	/* USER CODE END PM */
//
//	/* Private variables ---------------------------------------------------------*/
//	UART_HandleTypeDef huart1;
//	UART_HandleTypeDef huart2;
//	UART_HandleTypeDef huart3;
//
//	/* USER CODE BEGIN PV */
//	/*
//
//	*/
//	/* USER CODE END PV */
//
//	/* Private function prototypes -----------------------------------------------*/
//	void SystemClock_Config(void);
//	static void MX_GPIO_Init(void);
//	static void MX_USART2_UART_Init(void);
//	static void MX_USART1_UART_Init(void);
//	static void MX_USART3_UART_Init(void);
//	/* USER CODE BEGIN PFP */
//
//	// Litekit
//	void moves(uint8_t* move);
//
//	//void turn45(uint8_t* move);
//	int movel(uint8_t* move, int duration);
//
//	//printing
//	void myprint(char* str);
//	void intprint(uint16_t val);
//
//	// Pixy Camera function declarations
//	int8_t getVersion();
//	int8_t getResolution();
//	int8_t setCameraBrightness(uint8_t brightness);
//	int8_t getBlocks(uint8_t sigmap, uint8_t maxBlocks);
//	//checksum
//	int8_t checksumcal(uint8_t* array);
//	void rspeed(void);
//	void bspeed(void);
//	void lspeed(void);
//	void fspeed(void);
//
//
//	// Pixy Camera  declarations
//	#define PIXY_DEFAULT_ARGVAL                  0x80000000
//	#define PIXY_BUFFERSIZE                      0x104
//	#define PIXY_CHECKSUM_SYNC                   0xc1af
//	#define PIXY_NO_CHECKSUM_SYNC                0xc1ae
//	#define PIXY_SEND_HEADER_SIZE                4
//	#define PIXY_MAX_PROGNAME                    33
//	#define PIXY_VERSION_BUFFERSIZE              22
//	#define PIXY_RESOLUTION_BUFFERSIZE           10
//
//	#define PIXY_TYPE_REQUEST_CHANGE_PROG        0x02
//	#define PIXY_TYPE_REQUEST_RESOLUTION         0x0c
//	#define PIXY_TYPE_RESPONSE_RESOLUTION        0x0d
//	#define PIXY_TYPE_REQUEST_VERSION            0x0e
//	#define PIXY_TYPE_RESPONSE_VERSION           0x0f
//	#define PIXY_TYPE_RESPONSE_RESULT            0x01
//	#define PIXY_TYPE_RESPONSE_ERROR             0x03
//	#define PIXY_TYPE_REQUEST_BRIGHTNESS         0x10
//	#define PIXY_TYPE_REQUEST_GETBLOCKS			 0x20
//	#define PIXY_TYPE_REQUEST_SERVO              0x12
//	#define PIXY_TYPE_REQUEST_LED                0x14
//	#define PIXY_TYPE_REQUEST_LAMP               0x16
//	#define PIXY_TYPE_REQUEST_FPS                0x18
//
//	#define PIXY_RESULT_OK                       0
//	#define PIXY_RESULT_ERROR                    -1
//	#define PIXY_RESULT_BUSY                     -2
//	#define PIXY_RESULT_CHECKSUM_ERROR           -3
//	#define PIXY_RESULT_TIMEOUT                  -4
//	#define PIXY_RESULT_BUTTON_OVERRIDE          -5
//	#define PIXY_RESULT_PROG_CHANGING            -6
//
//	// Pixy Camera getVersion declarations
//	//uint8_t RequestPacket[4] = {0xc1, 0xae, 0x0e, 0x00};
//	uint8_t reqV[] = {PIXY_NO_CHECKSUM_SYNC&0xff, PIXY_NO_CHECKSUM_SYNC>>8, PIXY_TYPE_REQUEST_VERSION, 0x00};
//	uint8_t recV[PIXY_VERSION_BUFFERSIZE];
//	int8_t checksumstateV = 0;
//	int8_t checksumstateR = 0;
//	int8_t checksumstateB = 0;
//	int8_t checksumstateG = 0;
//	// Pixy Camera getResolution declarations
//	uint16_t getWidth = 0, getHeight = 0;
//	//uint16_t 16BitChksum = 0;
//	// Order: 1st byte of no_checksum_sync, 2nd byte of no_checksum_sync, 3rd byte-version request type, 4th byte-data length 1, 5th byte unused
//	uint8_t reqR[] = {PIXY_NO_CHECKSUM_SYNC&0xff, PIXY_NO_CHECKSUM_SYNC>>8, PIXY_TYPE_REQUEST_RESOLUTION, 0x01, 0xFF};
//	uint8_t VerR[] = {0xAE, 0xc1, 0x0d, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
//	uint8_t recR[10];
//
//	// Pixy Camera setCameraBrightness declarations
//	//uint8_t setbright = 0;	// value of brightness to be 0 to 255 //add static if required
//	// Order: Sync byte, sync byte, type of packet, length of payload, brightness
//	uint8_t reqB[] = {PIXY_NO_CHECKSUM_SYNC&0xff, PIXY_NO_CHECKSUM_SYNC>>8, PIXY_TYPE_REQUEST_BRIGHTNESS, 0x01, 0xFF};
//	uint8_t recB[10];
//
//	// Pixy Camera getBlocks declarations
//	uint8_t reqG[] = {PIXY_NO_CHECKSUM_SYNC&0xff, PIXY_NO_CHECKSUM_SYNC>>8, PIXY_TYPE_REQUEST_GETBLOCKS, 0x02, 0x01, 0x01};
//	uint8_t recG[20];
//	uint16_t X_BlkPix;  // 16-bit X (center) of block in pixels
//	uint16_t Y_BlkPix;  // 16-bit Y (center) of block in pixels
//	uint16_t WidthPix;  // 16-bit Width of block in pixels
//	uint16_t HeightPix; // 16-bit Height of block in pixels
//	uint16_t area;
//	uint16_t zval; //initial value
//	uint16_t xval; //initial value
//	int8_t xstate;// -1(left), 0(neutral) , 1 (right)
//	int8_t zstate;// -1(going further), 0(neutral) , 1 (going nearer)
//	//checksum
//	uint16_t checksum = 0;
//	uint16_t cal_checksum = 0;
//	//motor
//	   const uint8_t dur = 0x64; //duration value
//	  //3byes for data for all movements: direction, duration, speed, checksum
//	  uint8_t fwd[] = {0x14, 0x01, 0x1E, 0x01}; //forward
//	  uint8_t bck[] = {0x14, 0x02, 0x1E, 0x01};//backward
//	  uint8_t left[] = {0x14, 0x03, 0x1E, 0x01};//turn left commented for now since not used
//	  uint8_t right[] = {0x14, 0x04, 0x1E, 0x01};//turn right
//	  uint8_t sleft[] = {0x14, 0x05, 0x1E, 0x01};//side left
//	  uint8_t sright[] = {0x14, 0x06,0x1E, 0x01};//side right
//	  uint8_t tleft[] = {0x14, 0x07, 0x1E, 0x01};//top left
//	  uint8_t tright[] = {0x14, 0x08, 0x1E, 0x01};// top right
//	  uint8_t bleft[] = {0x14, 0x09, 0x1E, 0x01};//bottom left
//	  uint8_t bright[] = {0x14, 0x0A, 0x1E, 0x01};//bottom right
//	  uint8_t stop[] = {0x14, 0x0B, 0x1E, 0x01};//stop
//	  uint8_t speed = 0; //will further be initalized in speed function
//
//	/* USER CODE END PFP */
//
//	/* Private user code ---------------------------------------------------------*/
//	/* USER CODE BEGIN 0 */
//
//	/* USER CODE END 0 */
//
//	/**
//	  * @brief  The application entry point.
//	  * @retval int
//	  */
//	int main(void)
//	{
//	  /* USER CODE BEGIN 1 */
//
//
//	  /* USER CODE END 1 */
//
//	  /* MCU Configuration--------------------------------------------------------*/
//
//	  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
//	  HAL_Init();
//
//	  /* USER CODE BEGIN Init */
//
//	  /* USER CODE END Init */
//
//	  /* Configure the system clock */
//	  SystemClock_Config();
//
//	  /* USER CODE BEGIN SysInit */
//
//	  /* USER CODE END SysInit */
//
//	  /* Initialize all configured peripherals */
//	  MX_GPIO_Init();
//	  MX_USART2_UART_Init();
//	  MX_USART1_UART_Init();
//	  MX_USART3_UART_Init();
//	  /* USER CODE BEGIN 2 */
//
//	  /* USER CODE END 2 */
//
//	  /* Infinite loop */
//	  /* USER CODE BEGIN WHILE */
//
//	  while(1)//check for valid checksum
//	  {
//		checksumstateV = getVersion();
//		HAL_Delay(1);
//		checksumstateR = getResolution();
//		HAL_Delay(1);
//		checksumstateB = setCameraBrightness(100);
//		HAL_Delay(1);
//		HAL_Delay(100);
//		checksumstateG = getBlocks(1,1);
//		HAL_Delay(1);
//		xval = X_BlkPix;//store initial state of x axis
//		zval = area;//store initial state of z axis
//		//x axis in left and right, Z axis is away and near, with reference to Pixy Cam
//		if(checksumstateV == 0 && checksumstateR == 0 && checksumstateB == 0 && checksumstateG == 0)//only if all is valid
//		{
//			break;
//		}
//	  }
//
//	  while(1)//infininte main loop
//	  {
//
//		getBlocks(1,1);
//		while(!area) //till area value is valid
//		{
//			getBlocks(1,1);// current value of positon
//
//		}
//		uint16_t diff = (zval/100*5);//5% buffer
//		xstate = X_BlkPix>(xval+5)?1:X_BlkPix<(xval-5)?-1:0;//store xval state, buffer of 5 units
//		zstate = area>(zval+diff)?1:(area<(zval-diff)?-1:0);//store zval state
//
//
//		if(zstate == -1 && xstate == 0) //x going left and z in bigger
//		{
//			myprint("forward\n");
//			fspeed(); // set speed
//			movel(fwd, 10);//send direction and for 10 times
//		}
//		else if(zstate == -1 && xstate == 1)
//		{
//			myprint("top right\n");
//			rspeed();// set speed
//			movel(tright, 10);//send direction and for 10 times
//		}
//		else if(zstate == 1 && xstate == 0)
//		{
//			myprint("backwards\n");
//			bspeed();// set speed
//			movel(bck, 10);//send direction and for 10 times
//		}
//		else if(zstate == -1 && xstate ==-1)
//		{
//			myprint("top left\n");
//			lspeed();// set speed
//			movel(tleft, 10);//send direction and for 10 times
//		}
//		else if(zstate == 1 && xstate ==-1)
//		{
//			myprint("bottom left\n");
//			lspeed();// set speed
//			movel(bleft, 10);//send direction and for 10 times
//		}
//		else if(zstate == 1 && xstate == 1)
//		{
//			myprint("bottom right\n");
//			rspeed();// set speed
//			movel(bright, 10);//send direction and for 10 times
//		}
//		else if(zstate == 0 && xstate == 1)
//		{
//			myprint("side right\n");
//			rspeed();// set speed
//			movel(sright, 10);//send direction and for 10 times
//		}
//		else if(zstate == 0 && xstate == -1)
//		{
//			myprint("side left\n");
//			lspeed();// set speed
//			movel(sleft, 10);//send direction and for 10 times
//		}
//		else
//		{
//			myprint("stop\n");
//			movel(stop, 10);//send direction and for 10 times
//			// no speed required
//		}
//		HAL_Delay(5);
//	  }
//
//	}
//	/* USER CODE END WHILE */
//
//			/* USER CODE BEGIN 3 */
//
//	unsigned int testmove(uint8_t*move, unsigned int test) //test movement that can be used if needed
//	{
//		for(;test!=0; test--)
//		{
//			HAL_Delay(20);
//			uint8_t state = 0x0E; //initial state is notok aka ntok
//			HAL_UART_Receive(&huart1, &state, sizeof(state), 100);
//			if(state == 0x0E)
//			{
//				break;
//			}
//			HAL_UART_Transmit(&huart1, move, sizeof(move), 100);
//
//		}
//		return test;
//	}
//
//	void moves(uint8_t* move)//moves is move stop, used for stop
//	{
//		for(int i = 0; i<50; i++)
//		{
//			HAL_Delay(20);
//			HAL_UART_Transmit(&huart1, move, sizeof(move), 100);
//		}
//	}
//	int movel(uint8_t* move, int duration)//movel is move long, used for all other movements
//	{
//		move[2] = speed; //store speed
//		move[3] = move[0] + move[1] + move[2];//store check sum by addition as total val is below 255
//		for(int i = 0; i<duration;)//loop for
//		{
//			HAL_Delay(20);
//			uint8_t state = 0x0E; //initial state is notok aka ntok
//			HAL_UART_Receive(&huart1, &state, sizeof(state), 10); //receive and store
//			HAL_UART_Transmit(&huart1, move, sizeof(move), 10);//transmit movement to comm2control
//			if(state == 0x0F)//check state so that transmission only occurs when no obstacle
//			{
//				i++; //increment only if transmitted
//			}
//		}
//		return 1;
//	}
//	void turn45(uint8_t* move)//for 45 degree movement if required
//	{
//		for(int i = 0; i<1800; i++)
//		{
//				HAL_UART_Transmit(&huart1, move, sizeof(move), 200);
//		}
//
//	}
//
//	void rspeed(void)//right speed calculation
//	{
//		//can be multipled with other values to get different value for testing
//		speed = ((X_BlkPix - xval)/10)*10;//calculate change for acceleration
//		speed = speed>30?30:speed;//cap speed at 30
//	}
//	void lspeed(void)//left speed calculation
//	{
//		speed = ((xval - X_BlkPix)/10)*10;//calculate change for acceleration
//		speed = speed>30?30:speed;//cap speed at 30
//	}
//	void fspeed(void)//front speed calculation
//	{
//		speed = ((zval - area)/area) * 20;//calculate change for acceleration
//		speed = speed>30?30:speed;//cap speed at 30
//	}
//	void bspeed(void)//Back speed calculation
//	{
//		speed = ((area - zval)/zval) * 20;//calculate change for acceleration
//		speed = speed>30?30:speed;//cap speed at 30
//	}
//	//print a string of max 50 letters
//	void myprint(char *str)//print a sting of max 50 char
//	{
//		char print[50] = {'\0'}; // buffer
//		sprintf(print, "%s", str);
//		HAL_UART_Transmit(&huart2, (uint8_t *)print, strlen(print), 100);
//
//	}
//	//print a 2byte int
//	void intprint(uint16_t val)//print an unsigned int
//	{
//		char print[50] = {'\0'}; // buffer
//		sprintf(print, "%u", val);
//		HAL_UART_Transmit(&huart2, (uint8_t *)print, strlen(print), 100);
//	}
//	// PIXY CAMERA
//
//
//	// Order: 1st byte of no_checksum_sync, 2nd byte of no_checksum_sync, 3rd byte-version request type, 4th byte-data length 0
//	// To request hardware and firmware version data
//
//	int8_t checksumcal(uint8_t* array)//calculate checksum of pixycam
//	{
//		checksum = array[5] << 8 | array[4];
//		cal_checksum = 0;
//		for(int i = 6; i<22;i++)
//		{
//			cal_checksum+=array[i];
//		}
//		return checksum==cal_checksum?PIXY_RESULT_OK:PIXY_RESULT_ERROR;
//	}
//	int8_t getVersion()//get the current version of  Pixy cam
//	{
//		HAL_UART_Transmit(&huart3, reqV, 4, 100);
//		HAL_UART_Receive(&huart3, recV, PIXY_VERSION_BUFFERSIZE, 100);
//		HAL_Delay(1);
//		return checksumcal(recV);
//		//if loop to check error;
//	}
//	// getResolution gets the width and height of the frames used by the current program
//	int8_t getResolution()//get the resolution of  Pixy cam
//	{
//		HAL_UART_Transmit(&huart3, reqR, 5, 100);
//		HAL_UART_Receive(&huart3, recR, 10, 100);
//		HAL_Delay(1);
//		return checksumcal(recR);
//	}
//	// setCameraBrightness
//	// Taken from Pixy camera docu: sets the relative exposure level of Pixy2's image sensor. Higher values result in a brighter (more exposed) image.
//	// Verify brightness response packet
//	// Order: 8 bit sync byte, 8 bit sync byte, types of packet, length of payload, 4-5 16 bit checksum, 6-9 32 bit brightness
//	uint8_t VerBright[] = {0xC1, 0xAF, 0x01, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
//	int8_t setCameraBrightness(uint8_t setbright)//set the current brightness of  Pixy cam, set to 100 for testing
//	{
//		reqB[4] = setbright;//store brightness value
//		HAL_UART_Transmit(&huart3, reqB, 5, 100);
//		HAL_UART_Receive(&huart3, recB, 10, 100);
//		HAL_Delay(1);
//		checksum = recB[5] << 8 | recB[4];
//		cal_checksum = 0;
//		for(int i = 6; i<sizeof(recB);i++)
//		{
//			cal_checksum+=recB[i];
//		}
//		return checksum==cal_checksum?PIXY_RESULT_OK:PIXY_RESULT_ERROR;
//	}
//	// if receive center of object that litekit is tracking, how to use coordinates to classify movements slight left?
//	// diagonally left? coordinates and size must take this into account, use get blocks, set threshold when setting motion
//	// based on height and width of object
//	// if moves further away, center of object moves to the right andf getting smaller, motion cannot be just slightly right
//	// must be diagonally right
//	// devise this into flowchart
//
//	// getBlocks, gets all the detected blocks in the most recent frame
//	// Description taken from pixy cam documentation
//	// the returned blocks are sorted by area, with the largest blocks appearing first in the blocks array.
//	// returns an error value (<0) if it fails and the number of detected blocks (>=0) if it succeeds.
//	// sigmap is a bitmap of all 7 signatures from which you wish to receive block data.
//	// if you are only interested in block data from signature 1, you would pass in a value of 1.
//	// If you are interested in block data from both signatures 1 and 2, you would pass in a value of 3.
//	// If you are interested in block data from signatures 1, 2, and 3, you would pass a value of 7, and so on.
//	// The most-significant-bit (128 or 0x80) is used for color-codes.
//	// A value of 255 (default) indicates that you are interested in all block data.
//
//	// maxblocks is the maximum number of blocks you want to receive.
//	// passing 1 will receive one block, passing 255 will receive all blocks.
//
//	//uint8_t sigmap = 0xFF;//for sigmap value for 1
//	//uint8_t maxBlocks = 0x01;
//	//uint8_t VerBlock[] = {0xC1, 0xAF, 0x21, 0x0E, 0x00, 0x00, // last two bytes are sum of payload bytes
//	//					  0x00, 0x00, 0x00, 0x00, // 16-bit signature, 16-bit X (center) of block in pixels
//	//					  0x00, 0x00, 0x00, 0x00, // 16-bit Y (center) of block in pixels, 16-bit Width of block in pixels
//	//					  0x00, 0x00, 0x00, 0x00, // 16-bit Height of block in pixels, 16-bit Angle of color-code in degrees
//	//					  0x00, 0x00			  // Tracking index of block (see API for more info), Age - number of frames this block has been tracked
//	//					  };
//	//
//
//	//
//	//uint16_t signature = 0; // colour code number
//	//uint16_t X_BlkPix = 0;  // 16-bit X (center) of block in pixels
//	//uint16_t Y_BlkPix = 0;  // 16-bit Y (center) of block in pixels
//	//uint16_t WidthPix = 0;  // 16-bit Width of block in pixels
//	//uint16_t HeightPix = 0; // 16-bit Height of block in pixels
//	//int16_t AngleCode = 0; // 16-bit Angle of color-code in degrees -180 - 180 (0 if not a color code)
//	//uint8_t TrackIdx = 0;   // Tracking index of block (see API for more info)
//	//uint8_t Age = 0;	    // Age - number of frames this block has been tracked
//	//int16_t getPayloadSum = 0;
//
//	int8_t getBlocks(uint8_t sigmap, uint8_t maxBlocks)//getblocks function to get X,Y coordinates and Calculate Area
//	{
//		HAL_UART_Transmit(&huart3, reqG, 6, 100);
//		HAL_UART_Receive(&huart3, recG, 20, 100);
//		X_BlkPix = ((uint16_t)recG[9] << 8)| recG[8];//Bitshift to find x Val
//		Y_BlkPix = ((uint16_t)recG[11] << 8)| recG[10];//Bitshift to find Y Val
//		WidthPix = ((uint16_t)recG[13] << 8)| recG[12];//Bitshift to find Width
//		HeightPix = ((uint16_t)recG[15] << 8)| recG[14];//Bitshift to find Height
//		area = WidthPix*HeightPix;// Calculate and store area
//		checksum = recG[5] << 8 | recG[4];
//		cal_checksum = 0;
//		for(int i = 6; i<sizeof(recG);i++)
//		{
//			cal_checksum+=recG[i];
//		}
//		return checksum==cal_checksum?PIXY_RESULT_OK:PIXY_RESULT_ERROR;
//
//	}
//
//	  /* USER CODE END 3 */
//
//
//	/**
//	  * @brief System Clock Configuration
//	  * @retval None
//	  */
//	void SystemClock_Config(void)
//	{
//	  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
//	  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
//
//	  /** Initializes the RCC Oscillators according to the specified parameters
//	  * in the RCC_OscInitTypeDef structure.
//	  */
//	  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
//	  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
//	  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
//	  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
//	  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI_DIV2;
//	  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL16;
//	  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
//	  {
//		Error_Handler();
//	  }
//
//	  /** Initializes the CPU, AHB and APB buses clocks
//	  */
//	  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
//								  |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
//	  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
//	  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
//	  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
//	  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
//
//	  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
//	  {
//		Error_Handler();
//	  }
//	}
//
//	/**
//	  * @brief USART1 Initialization Function
//	  * @param None
//	  * @retval None
//	  */
//	static void MX_USART1_UART_Init(void)
//	{
//
//	  /* USER CODE BEGIN USART1_Init 0 */
//
//	  /* USER CODE END USART1_Init 0 */
//
//	  /* USER CODE BEGIN USART1_Init 1 */
//
//	  /* USER CODE END USART1_Init 1 */
//	  huart1.Instance = USART1;
//	  huart1.Init.BaudRate = 115200;
//	  huart1.Init.WordLength = UART_WORDLENGTH_8B;
//	  huart1.Init.StopBits = UART_STOPBITS_1;
//	  huart1.Init.Parity = UART_PARITY_NONE;
//	  huart1.Init.Mode = UART_MODE_TX_RX;
//	  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
//	  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
//	  if (HAL_UART_Init(&huart1) != HAL_OK)
//	  {
//		Error_Handler();
//	  }
//	  /* USER CODE BEGIN USART1_Init 2 */
//
//	  /* USER CODE END USART1_Init 2 */
//
//	}
//
//	/**
//	  * @brief USART2 Initialization Function
//	  * @param None
//	  * @retval None
//	  */
//	static void MX_USART2_UART_Init(void)
//	{
//
//	  /* USER CODE BEGIN USART2_Init 0 */
//
//	  /* USER CODE END USART2_Init 0 */
//
//	  /* USER CODE BEGIN USART2_Init 1 */
//
//	  /* USER CODE END USART2_Init 1 */
//	  huart2.Instance = USART2;
//	  huart2.Init.BaudRate = 115200;
//	  huart2.Init.WordLength = UART_WORDLENGTH_8B;
//	  huart2.Init.StopBits = UART_STOPBITS_1;
//	  huart2.Init.Parity = UART_PARITY_NONE;
//	  huart2.Init.Mode = UART_MODE_TX_RX;
//	  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
//	  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
//	  if (HAL_UART_Init(&huart2) != HAL_OK)
//	  {
//		Error_Handler();
//	  }
//	  /* USER CODE BEGIN USART2_Init 2 */
//
//	  /* USER CODE END USART2_Init 2 */
//
//	}
//
//	/**
//	  * @brief USART3 Initialization Function
//	  * @param None
//	  * @retval None
//	  */
//	static void MX_USART3_UART_Init(void)
//	{
//
//	  /* USER CODE BEGIN USART3_Init 0 */
//
//	  /* USER CODE END USART3_Init 0 */
//
//	  /* USER CODE BEGIN USART3_Init 1 */
//
//	  /* USER CODE END USART3_Init 1 */
//	  huart3.Instance = USART3;
//	  huart3.Init.BaudRate = 115200;
//	  huart3.Init.WordLength = UART_WORDLENGTH_8B;
//	  huart3.Init.StopBits = UART_STOPBITS_1;
//	  huart3.Init.Parity = UART_PARITY_NONE;
//	  huart3.Init.Mode = UART_MODE_TX_RX;
//	  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
//	  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
//	  if (HAL_UART_Init(&huart3) != HAL_OK)
//	  {
//		Error_Handler();
//	  }
//	  /* USER CODE BEGIN USART3_Init 2 */
//
//	  /* USER CODE END USART3_Init 2 */
//
//	}
//
//	/**
//	  * @brief GPIO Initialization Function
//	  * @param None
//	  * @retval None
//	  */
//	static void MX_GPIO_Init(void)
//	{
//	  GPIO_InitTypeDef GPIO_InitStruct = {0};
//
//	  /* GPIO Ports Clock Enable */
//	  __HAL_RCC_GPIOC_CLK_ENABLE();
//	  __HAL_RCC_GPIOD_CLK_ENABLE();
//	  __HAL_RCC_GPIOA_CLK_ENABLE();
//	  __HAL_RCC_GPIOB_CLK_ENABLE();
//
//	  /*Configure GPIO pin Output Level */
//	  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);
//
//	  /*Configure GPIO pin : B1_Pin */
//	  GPIO_InitStruct.Pin = B1_Pin;
//	  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
//	  GPIO_InitStruct.Pull = GPIO_NOPULL;
//	  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);
//
//	  /*Configure GPIO pin : LD2_Pin */
//	  GPIO_InitStruct.Pin = LD2_Pin;
//	  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
//	  GPIO_InitStruct.Pull = GPIO_NOPULL;
//	  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
//	  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);
//
//	  /* EXTI interrupt init*/
//	  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
//	  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);
//
//	}
//
//	/* USER CODE BEGIN 4 */
//
//	/* USER CODE END 4 */
//
//	/**
//	  * @brief  This function is executed in case of error occurrence.
//	  * @retval None
//	  */
//	void Error_Handler(void)
//	{
//	  /* USER CODE BEGIN Error_Handler_Debug */
//	  /* User can add his own implementation to report the HAL error return state */
//	  __disable_irq();
//	  while (1)
//	  {
//	  }
//	  /* USER CODE END Error_Handler_Debug */
//	}
//
//	#ifdef  USE_FULL_ASSERT
//	/**
//	  * @brief  Reports the name of the source file and the source line number
//	  *         where the assert_param error has occurred.
//	  * @param  file: pointer to the source file name
//	  * @param  line: assert_param error line source number
//	  * @retval None
//	  */
//	void assert_failed(uint8_t *file, uint32_t line)
//	{
//	  /* USER CODE BEGIN 6 */
//	  /* User can add his own implementation to report the file name and line number,
//		 ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
//	  /* USER CODE END 6 */
//	}
//	#endif /* USE_FULL_ASSERT */


